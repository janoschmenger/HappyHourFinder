export const environment = {
  firebaseConfig: {
    apiKey: "AIzaSyD2vC9sCLaEGumHqkHltVDUrmUXtuOwqfw",
    authDomain: "musikverleih-cf590.firebaseapp.com",
    projectId: "musikverleih-cf590",
    storageBucket: "musikverleih-cf590.appspot.com",
    messagingSenderId: "513790401642",
    appId: "1:513790401642:web:92e5e6cbf96119f5f73e13"
  },
  production: false
};