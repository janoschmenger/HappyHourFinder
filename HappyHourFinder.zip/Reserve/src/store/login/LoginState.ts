export interface LoginState {
    error: any;
    isRecoveredPassword: boolean;
    isRecoveringPassword: boolean;
    isLoggedIn: boolean;
    isLoggingIn: boolean;
}