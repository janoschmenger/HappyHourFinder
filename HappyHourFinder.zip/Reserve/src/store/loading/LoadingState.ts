export interface LoadingState {
    show: boolean;
}