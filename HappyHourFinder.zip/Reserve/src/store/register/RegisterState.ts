export class RegisterState {
    error: any;
    isRegistered: boolean;
    isRegistering: boolean;
}