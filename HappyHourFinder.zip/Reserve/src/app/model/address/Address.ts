export class Address {
    address: string;
    number: string;
    neighborhood: string;
    complement: string;
    zipCode: string;
    state: string;
    city: string;
}