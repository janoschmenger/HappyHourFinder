export class User {
    email: string;
    id: string;
}