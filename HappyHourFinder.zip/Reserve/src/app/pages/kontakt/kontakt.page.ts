import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-kontakt',
  templateUrl: './kontakt.page.html',
  styleUrls: ['./kontakt.page.scss'],
})
export class KontaktPage implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  public form = [
      { val: 'Ich habe die Datenschutzerklärung gelesen', isChecked: false },
      { val: 'Ich erkläre mich mit den Nutzungsbedingungen einverstanden', isChecked: false }
    ];
  
    goToLogin(){
      alert("Du wirst jetzt abgemeldet")
      this.router.navigate(['loader']);
    }
}
