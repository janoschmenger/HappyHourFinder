# reciclica-app
Aplicativo de reciclagem
